from __future__ import annotations

import argparse
import sys

import numpy as np
import torch
from sklearn.preprocessing import StandardScaler

from common import (
    CTMAPPER_ROOT,
    EDGE_ROOT,
    EMAC_PJ,
    EXTENSIONS_ROOT,
    base_result,
    load_hhk,
    measure_mean_latency,
    measure_peak_memory,
    profile_macs,
    run_dir,
    write_json,
)


def import_ctmapper():
    sys.path.insert(0, str(EXTENSIONS_ROOT))
    sys.path.insert(0, str(CTMAPPER_ROOT))
    # The Python wrappers import the six compiled extensions by top-level name.
    for module_dir in (
        "calc_assoc",
        "calc_pixel_feats",
        "calc_spixel_feats",
        "init_spixel_feats",
        "rel_to_abs_index",
        "smear",
    ):
        sys.path.insert(0, str(CTMAPPER_ROOT / "lib" / module_dir))
    import SamMapperMix

    return SamMapperMix


def build_model(module, height: int, width: int) -> torch.nn.Module:
    torch.manual_seed(42)
    torch.cuda.manual_seed_all(42)
    return module.SamMapperMix(
        height,
        width,
        108,
        8,
        2,
        2,
        2,
        2,
        1.0 / 3.0,
        121,
    ).cuda().eval()


def execute_profile(model, sample: torch.Tensor, warmup: int, repeat: int):
    with torch.inference_mode():
        output = model(sample)
    torch.cuda.synchronize()
    logits = output[0] if isinstance(output, tuple) else output
    expected_pixels = sample.shape[0] * sample.shape[1]
    if logits.shape != (expected_pixels, 8):
        raise RuntimeError(f"CTMapper returned {tuple(logits.shape)}, expected {(expected_pixels, 8)}")
    macs, profiling_tool = profile_macs(model, sample)
    peak_mb = measure_peak_memory(model, sample)
    mean_ms = measure_mean_latency(model, [sample], warmup, repeat)
    return macs, profiling_tool, peak_mb, mean_ms


def main() -> None:
    parser = argparse.ArgumentParser(description="Profile CTMapper on the HHK scene with explicit tile fallback")
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--full-scene", action="store_true")
    parser.add_argument("--oom-fallback", choices=["tile"], default="tile")
    parser.add_argument("--tile-size", type=int, default=256)
    parser.add_argument("--warmup", type=int, default=50)
    parser.add_argument("--repeat", type=int, default=50)
    args = parser.parse_args()
    if not args.full_scene or (args.tile_size, args.warmup, args.repeat) != (256, 50, 50):
        raise ValueError("arguments do not match the fixed camera-ready CTMapper protocol")

    target = run_dir(args.run_id)
    image, _ = load_hhk()
    height, width, channels = image.shape
    normalized = StandardScaler().fit_transform(image.reshape(-1, channels)).reshape(image.shape).astype(np.float32)
    del image
    module = import_ctmapper()

    mode = "full-scene"
    method = "CTMapper"
    task_input = f"one full {height}x{width}x{channels} HHK scene"
    input_array = normalized
    model = None
    sample = None

    try:
        # Include model construction and host-to-device transfer in the OOM
        # decision so every full-scene CUDA OOM uses the disclosed tile path.
        model = build_model(module, height, width)
        sample = torch.from_numpy(np.ascontiguousarray(input_array)).cuda()
        macs, _, peak_mb, mean_ms = execute_profile(model, sample, args.warmup, args.repeat)
    except torch.cuda.OutOfMemoryError:
        del sample, model
        torch.cuda.empty_cache()
        mode = "tiled"
        method = "CTMapper-tiled"
        task_input = "one 256x256x108 HHK tile"
        row0 = (height - args.tile_size) // 2
        col0 = (width - args.tile_size) // 2
        input_array = normalized[row0 : row0 + args.tile_size, col0 : col0 + args.tile_size, :]
        model = build_model(module, args.tile_size, args.tile_size)
        sample = torch.from_numpy(np.ascontiguousarray(input_array)).cuda()
        macs, _, peak_mb, mean_ms = execute_profile(model, sample, args.warmup, args.repeat)
    energy_uj = macs * EMAC_PJ * 1e-6

    result = base_result(method, args.run_id, task_input, list(sample.shape))
    result.update(
        {
            "compute_gop_per_inference": macs / 1e9,
            "peak_gpu_memory_mb": peak_mb,
            "mean_latency_ms_per_inference": mean_ms,
            "estimated_energy_uj_per_inference": energy_uj,
            "profiled_mac": macs,
            "effective_ac": 0.0,
            "warmup_count": args.warmup,
            "measurement_count": args.repeat,
            "ctmapper_mode": mode,
        }
    )
    output_path = target / "ctmapper.json"
    write_json(output_path, result)
    print(f"{method} profiling complete: {output_path}")


if __name__ == "__main__":
    main()
