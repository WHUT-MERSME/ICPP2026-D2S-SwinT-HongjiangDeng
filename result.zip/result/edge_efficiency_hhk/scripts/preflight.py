from __future__ import annotations

import argparse
import shutil
import sys

import torch

from common import (
    D2S_ROOT,
    EDGE_ROOT,
    GSC_ROOT,
    HHK_DATA_PATH,
    HHK_GT_PATH,
    environment_payload,
    run_dir,
    write_json,
)


def main() -> None:
    parser = argparse.ArgumentParser(description="Validate the HHK efficiency profiling environment")
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()

    target = run_dir(args.run_id)
    checkpoint = D2S_ROOT / "d2s_result" / "ZY_HHK_2021" / "best_model.pth"
    missing = [str(path) for path in (HHK_DATA_PATH, HHK_GT_PATH, checkpoint) if not path.is_file()]
    if missing:
        raise FileNotFoundError("missing required files: " + ", ".join(missing))
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA GPU is required for the camera-ready profiling protocol")

    sys.path.insert(0, str(GSC_ROOT))
    from models.gscvit import gscvit

    model = gscvit("hhk").cuda().eval()
    sample = torch.zeros((1, 1, 30, 25, 25), device="cuda", dtype=torch.float32)
    with torch.inference_mode():
        output = model(sample)
    if list(output.shape) != [1, 8]:
        raise RuntimeError(f"GSC-ViT HHK smoke test returned {list(output.shape)}, expected [1, 8]")
    del sample, output, model
    torch.cuda.empty_cache()

    payload = environment_payload(args.run_id)
    payload.update(
        {
            "project_root": str(EDGE_ROOT.parents[1]),
            "output_root": str(EDGE_ROOT),
            "hhk_data": str(HHK_DATA_PATH),
            "hhk_gt": str(HHK_GT_PATH),
            "d2s_checkpoint": str(checkpoint),
            "nvcc": shutil.which("nvcc"),
            "cl": shutil.which("cl"),
            "gsc_hhk_smoke_output": [1, 8],
        }
    )
    write_json(target / "environment.json", payload)
    print(f"Preflight passed. Environment saved to {target / 'environment.json'}")
    if payload["cl"] is None:
        print("NOTE: cl.exe is not on PATH; the CTMapper build script will load the installed VS 2022 toolchain.")


if __name__ == "__main__":
    main()
