from __future__ import annotations

import argparse
import csv
from pathlib import Path

from common import read_json, run_dir


FIELDS = (
    "method",
    "dataset",
    "task_input",
    "input_shape",
    "compute_gop_per_inference",
    "peak_gpu_memory_mb",
    "mean_latency_ms_per_inference",
    "estimated_energy_uj_per_inference",
    "profiled_mac",
    "effective_ac",
    "warmup_count",
    "measurement_count",
    "ctmapper_mode",
    "gpu",
    "torch_version",
    "cuda_version",
    "run_id",
)


def main() -> None:
    parser = argparse.ArgumentParser(description="Aggregate the four HHK efficiency rows")
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    target = run_dir(args.run_id, create=False)
    sources = ["ctmapper.json", "gscvit.json", "d2s_t1.json", "d2s_t4.json"]
    rows = [read_json(target / name) for name in sources]

    forbidden = {"accuracy", "latency_std", "latency_p50", "latency_p95"}
    for row in rows:
        if set(row) != set(FIELDS):
            missing = sorted(set(FIELDS).difference(row))
            extra = sorted(set(row).difference(FIELDS))
            raise RuntimeError(
                f"result field whitelist mismatch for {row.get('method', '<unknown>')}: "
                f"missing={missing}, extra={extra}"
            )
        bad = forbidden.intersection(row)
        bad.update(key for key in row if key.startswith("per_pixel"))
        if bad:
            raise RuntimeError(f"forbidden result fields in {row['method']}: {sorted(bad)}")
        if row["warmup_count"] != 50 or row["measurement_count"] != 50:
            raise RuntimeError(f"invalid measurement counts for {row['method']}")
        for key in (
            "compute_gop_per_inference",
            "peak_gpu_memory_mb",
            "mean_latency_ms_per_inference",
            "estimated_energy_uj_per_inference",
        ):
            if float(row[key]) <= 0:
                raise RuntimeError(f"{row['method']} has invalid {key}={row[key]}")

    csv_path = target / "summary.csv"
    with csv_path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            serializable = dict(row)
            serializable["input_shape"] = "x".join(str(value) for value in row["input_shape"])
            writer.writerow(serializable)

    caption = (
        "Efficiency profiling on the Huanghekou dataset under FP32 inference with batch size 1 on the same GPU. "
        "Each value represents one complete inference task without pixel-level normalization. CTMapper processes "
        "the full HHK scene, or a 256x256 HHK tile when explicitly marked as CTMapper-tiled. GSC-ViT and "
        "D2S-SwinT use the same 25x25 spatial patch and 30 PCA components. ANN compute denotes tool-profiled "
        "MACs, whereas SNN compute includes initial MACs and "
        "effective ACs. Energy is operation-level estimated energy rather than hardware-measured energy. The "
        "HHK-adapted GSC-ViT architecture is used solely for efficiency profiling, with no accuracy claim. "
        "Custom CTMapper CUDA operations not recognized by the profiling tool, if any, are excluded from the "
        "reported compute count but remain included in latency and memory measurements."
    )
    (target / "methodology.md").write_text(caption + "\n", encoding="utf-8")
    print(f"Summary written to {csv_path}")


if __name__ == "__main__":
    main()
