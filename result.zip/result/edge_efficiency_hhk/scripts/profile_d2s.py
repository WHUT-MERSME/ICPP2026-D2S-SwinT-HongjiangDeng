from __future__ import annotations

import argparse
import sys

import numpy as np
import torch
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, TensorDataset

from common import (
    D2S_ROOT,
    EAC_PJ,
    EMAC_PJ,
    base_result,
    extract_patches,
    load_hhk,
    measure_mean_latency,
    measure_peak_memory,
    read_json,
    run_dir,
    write_json,
)


class ArgsECMT:
    def __init__(self) -> None:
        self.model = "vit"
        self.linear_num = 8
        self.qkv_num = 8
        self.softmax_num = 8
        self.softmax_p = 0.0125


def build_snn(checkpoint: str, calibration_patches: np.ndarray) -> torch.nn.Module:
    sys.path.insert(0, str(D2S_ROOT))
    from ECMT_uitls import trans_utils
    from swin_hsi_model_v2 import HSISwinModel

    model = HSISwinModel(num_classes=8, in_chans=30, img_size=25, drop_rate=0.0).cuda().eval()
    state = torch.load(checkpoint, map_location="cuda", weights_only=True)
    model.load_state_dict(state, strict=True)

    snn = trans_utils.replace_test_by_testneuron(model, percent=0.99).cuda()
    calibration_tensor = torch.from_numpy(calibration_patches).permute(0, 3, 1, 2)
    loader = DataLoader(TensorDataset(calibration_tensor), batch_size=32, shuffle=False)
    with torch.inference_mode():
        for batch_index, (images,) in enumerate(loader):
            snn(images.cuda())
            if batch_index + 1 >= 10:
                break
    snn = trans_utils.replace_nonlinear_by_neuron(snn)
    snn = trans_utils.replace_at_by_neuron(snn)
    snn = trans_utils.replace_testneuron_by_twosideneuron(snn, ArgsECMT())
    return snn.cuda().eval()


def collect_snn_ops(model: torch.nn.Module, inputs: list[torch.Tensor]) -> dict[int, tuple[float, float]]:
    from ECMT_uitls import trans_utils

    monitor = trans_utils.SOPMonitor(model, type=1)
    totals = {1: {"mac": [], "ac": []}, 4: {"mac": [], "ac": []}}
    with torch.inference_mode():
        for sample in inputs:
            trans_utils.reset_net(model)
            cumulative_mac = 0.0
            cumulative_ac = 0.0
            for timestep in range(1, 5):
                monitor.clear_recorded_data()
                model(sample)
                step_mac = 0.0
                step_ac = 0.0
                for layer_name, indices in monitor.name_records_index.items():
                    for record_index in indices:
                        record = monitor.records[record_index]
                        if layer_name == "proj":
                            step_mac += float(getattr(record, "potential_ops", record[1]))
                        else:
                            step_ac += float(getattr(record, "actual_ops", record[0]))
                cumulative_mac += step_mac
                cumulative_ac += step_ac
                if timestep in totals:
                    totals[timestep]["mac"].append(cumulative_mac)
                    totals[timestep]["ac"].append(cumulative_ac)
    monitor.total_actual_ops = 0.0
    monitor.total_potential_ops = 0.0
    monitor.remove_hooks()
    del monitor
    return {
        timestep: (float(np.mean(values["mac"])), float(np.mean(values["ac"])))
        for timestep, values in totals.items()
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Profile D2S-SwinT T=1 and T=4 on shared HHK patches")
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--timesteps", type=int, nargs="+", default=[1, 4])
    parser.add_argument("--patch-size", type=int, default=25)
    parser.add_argument("--pca-components", type=int, default=30)
    parser.add_argument("--warmup", type=int, default=50)
    parser.add_argument("--repeat", type=int, default=50)
    args = parser.parse_args()
    if (args.timesteps, args.patch_size, args.pca_components, args.warmup, args.repeat) != ([1, 4], 25, 30, 50, 50):
        raise ValueError("arguments do not match the fixed camera-ready D2S protocol")

    target = run_dir(args.run_id)
    coords_payload = read_json(target / "sample_coordinates.json")
    selected_coords = coords_payload["samples"]
    image, gt = load_hhk()

    flat = image.reshape(-1, image.shape[-1]).astype(np.float32)
    pca = PCA(n_components=30, whiten=True)
    transformed = pca.fit_transform(flat).reshape(image.shape[0], image.shape[1], 30).astype(np.float32)
    test_patches = extract_patches(transformed, selected_coords, 25)

    rows, cols = np.where(gt > 0)
    labels = gt[rows, cols].astype(np.int64) - 1
    train_indices, _ = train_test_split(
        np.arange(len(rows)), test_size=0.7, random_state=345, stratify=labels
    )
    rng = np.random.default_rng(345)
    calibration_indices = rng.choice(train_indices, size=min(512, len(train_indices)), replace=False)
    calibration_coords = [
        {"row": int(rows[index]), "col": int(cols[index])} for index in calibration_indices
    ]
    calibration_patches = extract_patches(transformed, calibration_coords, 25)
    del flat, transformed, image, gt

    inputs_cpu = torch.from_numpy(test_patches).permute(0, 3, 1, 2)
    inputs = [inputs_cpu[index : index + 1].cuda() for index in range(len(inputs_cpu))]
    torch.manual_seed(42)
    torch.cuda.manual_seed_all(42)
    model = build_snn(args.checkpoint, calibration_patches)
    op_counts = collect_snn_ops(model, inputs)

    from ECMT_uitls import trans_utils

    for timestep in args.timesteps:
        def forward(sample: torch.Tensor, steps: int = timestep):
            trans_utils.reset_net(model)
            output = None
            for _ in range(steps):
                output = model(sample)
            return output

        peak_mb = measure_peak_memory(forward, inputs[0])
        mean_ms = measure_mean_latency(forward, inputs, args.warmup, args.repeat)
        macs, acs = op_counts[timestep]
        energy_uj = (macs * EMAC_PJ + acs * EAC_PJ) * 1e-6
        result = base_result(
            f"D2S-SwinT (T={timestep})",
            args.run_id,
            f"one 25x25x30 PCA HHK patch with {timestep} timestep(s)",
            [1, 30, 25, 25],
        )
        result.update(
            {
                "compute_gop_per_inference": (macs + acs) / 1e9,
                "peak_gpu_memory_mb": peak_mb,
                "mean_latency_ms_per_inference": mean_ms,
                "estimated_energy_uj_per_inference": energy_uj,
                "profiled_mac": macs,
                "effective_ac": acs,
                "warmup_count": args.warmup,
                "measurement_count": args.repeat,
                "ctmapper_mode": None,
            }
        )
        output = target / f"d2s_t{timestep}.json"
        write_json(output, result)
        print(f"D2S-SwinT T={timestep} profiling complete: {output}")


if __name__ == "__main__":
    main()
