from __future__ import annotations

import argparse

import numpy as np
from sklearn.model_selection import train_test_split

from common import load_hhk, run_dir, write_json


def stratified_subset(coords: np.ndarray, labels: np.ndarray, count: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    classes = sorted(np.unique(labels).tolist())
    base, remainder = divmod(count, len(classes))
    selected = []
    for class_index, class_id in enumerate(classes):
        candidates = np.flatnonzero(labels == class_id)
        take = base + (1 if class_index < remainder else 0)
        if len(candidates) < take:
            raise RuntimeError(f"class {class_id} has only {len(candidates)} test samples, need {take}")
        selected.extend(rng.choice(candidates, size=take, replace=False).tolist())
    selected = np.asarray(selected, dtype=np.int64)
    rng.shuffle(selected)
    return selected


def main() -> None:
    parser = argparse.ArgumentParser(description="Select deterministic HHK coordinates shared by GSC and D2S")
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--patch-size", type=int, default=25)
    parser.add_argument("--sample-count", type=int, default=50)
    parser.add_argument("--seed", type=int, default=345)
    args = parser.parse_args()
    if args.patch_size != 25:
        raise ValueError("the fixed camera-ready protocol requires patch-size=25")
    if args.sample_count != 50:
        raise ValueError("the fixed camera-ready protocol requires sample-count=50")

    _, gt = load_hhk()
    rows, cols = np.where(gt > 0)
    coords = np.column_stack([rows, cols])
    labels = gt[rows, cols].astype(np.int64) - 1
    _, test_indices = train_test_split(
        np.arange(len(coords)), test_size=0.7, random_state=args.seed, stratify=labels
    )
    test_coords = coords[test_indices]
    test_labels = labels[test_indices]
    chosen = stratified_subset(test_coords, test_labels, args.sample_count, args.seed)
    samples = [
        {"row": int(test_coords[i, 0]), "col": int(test_coords[i, 1]), "label": int(test_labels[i])}
        for i in chosen
    ]
    payload = {
        "dataset": "Huanghekou",
        "seed": args.seed,
        "patch_size": args.patch_size,
        "sample_count": len(samples),
        "samples": samples,
    }
    output = run_dir(args.run_id) / "sample_coordinates.json"
    write_json(output, payload)
    print(f"Saved {len(samples)} shared HHK coordinates to {output}")


if __name__ == "__main__":
    main()
