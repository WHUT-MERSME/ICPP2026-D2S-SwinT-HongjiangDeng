param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[A-Za-z0-9_.-]+$')]
    [string]$RunId
)

$ErrorActionPreference = 'Stop'
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..\..')).Path
$EdgeRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$CtRoot = Join-Path $ProjectRoot 'SAM-CTMapper-coastal-wetland-hyperspectral-image-classification-main'
$ExtensionRoot = Join-Path $EdgeRoot 'extensions'
$BuildRoot = Join-Path $EdgeRoot 'build_temp'
$RunRoot = Join-Path (Join-Path $EdgeRoot 'runs') $RunId

New-Item -ItemType Directory -Force -Path $ExtensionRoot, $BuildRoot, $RunRoot | Out-Null

if (-not (Get-Command nvcc.exe -ErrorAction SilentlyContinue)) {
    throw 'nvcc.exe is required; CUDA 12.1 was not found on PATH.'
}

# Reuse an installed Visual Studio toolchain even when this script is launched
# from an ordinary PowerShell session.
if (-not (Get-Command cl.exe -ErrorAction SilentlyContinue)) {
    $VsWhere = 'C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe'
    if (-not (Test-Path -LiteralPath $VsWhere)) {
        throw 'Visual Studio discovery tool vswhere.exe was not found.'
    }
    $VsInstall = (& $VsWhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath).Trim()
    if (-not $VsInstall) {
        throw 'An installed Visual Studio C++ toolchain was not found.'
    }
    $VsDevCmd = Join-Path $VsInstall 'Common7\Tools\VsDevCmd.bat'
    $EnvironmentLines = & $env:ComSpec /d /s /c "call `"$VsDevCmd`" -arch=x64 -host_arch=x64 >nul && set"
    foreach ($Line in $EnvironmentLines) {
        if ($Line -match '^([^=]+)=(.*)$') {
            [Environment]::SetEnvironmentVariable($Matches[1], $Matches[2], 'Process')
        }
    }
}
if (-not (Get-Command cl.exe -ErrorAction SilentlyContinue)) {
    throw 'cl.exe is required and could not be loaded from the installed Visual Studio instance.'
}

$env:TORCH_CUDA_ARCH_LIST = '8.9'
# PyTorch 2.4 requires this flag when the script is launched from an already
# activated Visual Studio developer environment. It prevents distutils from
# attempting to activate a second, conflicting MSVC toolchain.
$env:DISTUTILS_USE_SDK = '1'
# CUDA 12.1 predates the installed MSVC 14.41/14.42 version check. NVIDIA's
# compatibility switch only bypasses that check; it does not alter kernel math.
$env:NVCC_PREPEND_FLAGS = '-allow-unsupported-compiler -D_ALLOW_COMPILER_AND_STL_VERSION_MISMATCH'
$modules = @('calc_assoc', 'calc_pixel_feats', 'calc_spixel_feats', 'init_spixel_feats', 'rel_to_abs_index', 'smear')
foreach ($module in $modules) {
    $moduleRoot = Join-Path (Join-Path $CtRoot 'lib') $module
    $moduleBuild = Join-Path $BuildRoot $module
    New-Item -ItemType Directory -Force -Path $moduleBuild | Out-Null
    Push-Location $moduleRoot
    try {
        & python -B setup.py build_ext --build-lib $ExtensionRoot --build-temp $moduleBuild
        if ($LASTEXITCODE -ne 0) {
            throw "CUDA extension build failed for $module"
        }
    }
    finally {
        Pop-Location
    }
}

$env:PYTHONPATH = "$ExtensionRoot;$env:PYTHONPATH"
& python -B -c "import torch; import calc_assoc_cuda, calc_pixel_feats_cuda, calc_spixel_feats_cuda, init_spixel_feats_cuda, rel_to_abs_index_cuda, smear_cuda; print('CTMapper CUDA extensions imported successfully')"
if ($LASTEXITCODE -ne 0) {
    throw 'Compiled CTMapper extensions failed their import smoke test.'
}
