param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[A-Za-z0-9_.-]+$')]
    [string]$RunId
)

$ErrorActionPreference = 'Stop'
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..\..')).Path
Set-Location $ProjectRoot
$RunRoot = Join-Path (Join-Path (Resolve-Path (Join-Path $PSScriptRoot '..')).Path 'runs') $RunId
New-Item -ItemType Directory -Force -Path $RunRoot | Out-Null
$TranscriptStarted = $false

function Invoke-PythonStep {
    param([string[]]$Arguments)
    & python -B @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Python step failed: $($Arguments -join ' ')"
    }
}

try {
    Start-Transcript -Path (Join-Path $RunRoot 'experiment.log') -Force | Out-Null
    $TranscriptStarted = $true
    Invoke-PythonStep @('.\result\edge_efficiency_hhk\scripts\preflight.py', '--run-id', $RunId)
    & powershell -ExecutionPolicy Bypass -File '.\result\edge_efficiency_hhk\scripts\build_ctmapper_extensions.ps1' -RunId $RunId
    if ($LASTEXITCODE -ne 0) { throw 'CTMapper extension build failed.' }
    Invoke-PythonStep @('.\result\edge_efficiency_hhk\scripts\prepare_hhk_samples.py', '--run-id', $RunId, '--patch-size', '25', '--sample-count', '50', '--seed', '345')
    Invoke-PythonStep @('.\result\edge_efficiency_hhk\scripts\profile_gscvit.py', '--run-id', $RunId, '--config', 'hhk_pca30_adapted', '--patch-size', '25', '--group-size', '5', '--spectral-channels', '30', '--warmup', '50', '--repeat', '50')
    Invoke-PythonStep @('.\result\edge_efficiency_hhk\scripts\profile_d2s.py', '--run-id', $RunId, '--checkpoint', '.\Swin-HSI-main - copy\d2s_result\ZY_HHK_2021\best_model.pth', '--timesteps', '1', '4', '--patch-size', '25', '--pca-components', '30', '--warmup', '50', '--repeat', '50')
    Invoke-PythonStep @('.\result\edge_efficiency_hhk\scripts\profile_ctmapper.py', '--run-id', $RunId, '--full-scene', '--oom-fallback', 'tile', '--tile-size', '256', '--warmup', '50', '--repeat', '50')
    Invoke-PythonStep @('.\result\edge_efficiency_hhk\scripts\aggregate_results.py', '--run-id', $RunId)
}
finally {
    if ($TranscriptStarted) { Stop-Transcript | Out-Null }
}
