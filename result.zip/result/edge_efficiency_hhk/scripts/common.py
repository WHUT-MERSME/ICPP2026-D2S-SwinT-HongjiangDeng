from __future__ import annotations

import json
import platform
import re
import time
from pathlib import Path
from typing import Callable, Iterable

import numpy as np
import torch
from scipy import io


PROJECT_ROOT = Path(__file__).resolve().parents[3]
EDGE_ROOT = PROJECT_ROOT / "result" / "edge_efficiency_hhk"
RUNS_ROOT = EDGE_ROOT / "runs"
EXTENSIONS_ROOT = EDGE_ROOT / "extensions"
D2S_ROOT = PROJECT_ROOT / "Swin-HSI-main - copy"
GSC_ROOT = PROJECT_ROOT / "TGRS-GSC-VIT-master"
CTMAPPER_ROOT = PROJECT_ROOT / "SAM-CTMapper-coastal-wetland-hyperspectral-image-classification-main"
HHK_DATA_PATH = D2S_ROOT / "DataSet" / "ZY_HHK_2021" / "ZY_HHK_data108_20210929.mat"
HHK_GT_PATH = D2S_ROOT / "DataSet" / "ZY_HHK_2021" / "ZY_HHK_gt108_20210929.mat"
EMAC_PJ = 4.6
EAC_PJ = 0.9


def run_dir(run_id: str, create: bool = True) -> Path:
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", run_id):
        raise ValueError("run-id may contain only letters, digits, dot, underscore, and hyphen")
    target = (RUNS_ROOT / run_id).resolve()
    root = RUNS_ROOT.resolve()
    if target != root and root not in target.parents:
        raise ValueError(f"unsafe output path: {target}")
    if create:
        target.mkdir(parents=True, exist_ok=True)
    return target


def write_json(path: Path, payload: dict) -> None:
    resolved = path.resolve()
    if EDGE_ROOT.resolve() not in resolved.parents:
        raise ValueError(f"refusing to write outside {EDGE_ROOT}: {resolved}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def load_hhk() -> tuple[np.ndarray, np.ndarray]:
    image = io.loadmat(HHK_DATA_PATH)["Data"]
    gt = io.loadmat(HHK_GT_PATH)["DataClass"]
    if image.shape != (1050, 1219, 108) or gt.shape != (1050, 1219):
        raise RuntimeError(f"unexpected HHK shapes: image={image.shape}, gt={gt.shape}")
    return image, gt


def gsc_standardize(image: np.ndarray) -> np.ndarray:
    # Match the normalization used by the public GSC-ViT data loader.
    x = np.asarray(image, dtype=np.float32)
    value_range = float(x.max() - x.min())
    if value_range <= 0:
        raise RuntimeError("HHK image has zero dynamic range")
    x = (x - float(x.min())) / value_range
    x -= np.mean(x, axis=(0, 1), keepdims=True)
    return x


def extract_patches(image: np.ndarray, coords: Iterable[dict], patch_size: int) -> np.ndarray:
    if patch_size % 2 != 1:
        raise ValueError("patch_size must be odd")
    margin = patch_size // 2
    padded = np.pad(image, ((margin, margin), (margin, margin), (0, 0)), mode="reflect")
    patches = []
    for item in coords:
        row = int(item["row"])
        col = int(item["col"])
        patches.append(padded[row : row + patch_size, col : col + patch_size, :])
    return np.ascontiguousarray(np.stack(patches).astype(np.float32, copy=False))


def synchronize() -> None:
    if torch.cuda.is_available():
        torch.cuda.synchronize()


def measure_mean_latency(
    forward: Callable[[torch.Tensor], object],
    inputs: list[torch.Tensor],
    warmup: int,
    repeat: int,
) -> float:
    if not inputs:
        raise ValueError("latency input list is empty")
    with torch.inference_mode():
        for index in range(warmup):
            forward(inputs[index % len(inputs)])
        synchronize()
        total_ms = 0.0
        for index in range(repeat):
            sample = inputs[index % len(inputs)]
            synchronize()
            started = time.perf_counter()
            forward(sample)
            synchronize()
            total_ms += (time.perf_counter() - started) * 1e3
    return total_ms / repeat


def measure_peak_memory(forward: Callable[[torch.Tensor], object], sample: torch.Tensor) -> float:
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    with torch.inference_mode():
        forward(sample)
    synchronize()
    return float(torch.cuda.max_memory_allocated() / (1024**2))


def profile_macs(model: torch.nn.Module, sample: torch.Tensor) -> tuple[float, str]:
    """Return tool-profiled MACs without implementing custom-op FLOP formulas."""
    try:
        from thop import profile as thop_profile

        with torch.inference_mode():
            macs, _ = thop_profile(model, inputs=(sample,), verbose=False)
        return float(macs), "thop"
    except (ImportError, ModuleNotFoundError):
        pass

    activities = [torch.profiler.ProfilerActivity.CPU]
    if sample.is_cuda:
        activities.append(torch.profiler.ProfilerActivity.CUDA)
    with torch.inference_mode(), torch.profiler.profile(activities=activities, with_flops=True) as prof:
        model(sample)
        synchronize()
    total_flops = sum(float(event.flops or 0) for event in prof.key_averages())
    if total_flops <= 0:
        raise RuntimeError("PyTorch profiler did not report any FLOPs")
    return total_flops / 2.0, "torch.profiler(flops/2)"


def environment_payload(run_id: str) -> dict:
    return {
        "run_id": run_id,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "torch_version": torch.__version__,
        "cuda_build": torch.version.cuda,
        "cuda_available": torch.cuda.is_available(),
        "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        "gpu_capability": list(torch.cuda.get_device_capability(0)) if torch.cuda.is_available() else None,
        "fp32": True,
        "batch_size": 1,
    }


def base_result(method: str, run_id: str, task_input: str, input_shape: list[int]) -> dict:
    return {
        "method": method,
        "dataset": "Huanghekou",
        "task_input": task_input,
        "input_shape": input_shape,
        "gpu": torch.cuda.get_device_name(0),
        "torch_version": torch.__version__,
        "cuda_version": torch.version.cuda,
        "run_id": run_id,
    }
