from __future__ import annotations

import argparse
import sys

import numpy as np
import torch
from sklearn.decomposition import PCA

from common import (
    EMAC_PJ,
    GSC_ROOT,
    base_result,
    extract_patches,
    load_hhk,
    measure_mean_latency,
    measure_peak_memory,
    profile_macs,
    read_json,
    run_dir,
    write_json,
)


def main() -> None:
    parser = argparse.ArgumentParser(description="Profile the HHK-adapted GSC-ViT")
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--config", default="hhk_pca30_adapted")
    parser.add_argument("--patch-size", type=int, default=25)
    parser.add_argument("--group-size", type=int, default=5)
    parser.add_argument("--spectral-channels", type=int, default=30)
    parser.add_argument("--warmup", type=int, default=50)
    parser.add_argument("--repeat", type=int, default=50)
    args = parser.parse_args()
    expected = (args.config, args.patch_size, args.group_size, args.spectral_channels, args.warmup, args.repeat)
    if expected != ("hhk_pca30_adapted", 25, 5, 30, 50, 50):
        raise ValueError("arguments do not match the fixed camera-ready GSC-ViT protocol")

    target = run_dir(args.run_id)
    coordinate_payload = read_json(target / "sample_coordinates.json")
    coords = coordinate_payload["samples"]

    sys.path.insert(0, str(GSC_ROOT))
    from models.gscvit import gscvit

    image, _ = load_hhk()
    flat = image.reshape(-1, image.shape[-1]).astype(np.float32)
    pca = PCA(n_components=args.spectral_channels, whiten=True)
    transformed = pca.fit_transform(flat).reshape(image.shape[0], image.shape[1], args.spectral_channels)
    patches = extract_patches(transformed.astype(np.float32), coords, args.patch_size)
    patch_tensor = torch.from_numpy(patches).permute(0, 3, 1, 2).unsqueeze(1)
    inputs = [patch_tensor[i : i + 1].cuda(non_blocking=False) for i in range(len(patch_tensor))]

    torch.manual_seed(42)
    torch.cuda.manual_seed_all(42)
    model = gscvit("hhk").cuda().eval()
    with torch.inference_mode():
        smoke = model(inputs[0])
    if list(smoke.shape) != [1, 8]:
        raise RuntimeError(f"GSC-ViT returned {list(smoke.shape)}, expected [1, 8]")

    macs, _ = profile_macs(model, inputs[0])
    peak_mb = measure_peak_memory(model, inputs[0])
    mean_ms = measure_mean_latency(model, inputs, args.warmup, args.repeat)
    energy_uj = macs * EMAC_PJ * 1e-6

    result = base_result("GSC-ViT", args.run_id, "one 25x25x30 PCA HHK patch", [1, 1, 30, 25, 25])
    result.update(
        {
            "compute_gop_per_inference": macs / 1e9,
            "peak_gpu_memory_mb": peak_mb,
            "mean_latency_ms_per_inference": mean_ms,
            "estimated_energy_uj_per_inference": energy_uj,
            "profiled_mac": macs,
            "effective_ac": 0.0,
            "warmup_count": args.warmup,
            "measurement_count": args.repeat,
            "ctmapper_mode": None,
        }
    )
    output = target / "gscvit.json"
    write_json(output, result)
    print(f"GSC-ViT profiling complete: {output}")


if __name__ == "__main__":
    main()
